package app;

import app.aeropuerto.Aeropuerto;
import app.link.LinkReservaHotel;
import app.plan.*;
import app.ubicacion.Ciudad;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		//Ejemplo para probar el funcionamiento
		LocalDateTime fechaNacimiento = LocalDateTime.of(1997, 2, 1, 0, 0, 0);
		Usuario u = new Usuario("ejemplo", "ejemplo@gmail.com", 1, fechaNacimiento);

		Ciudad ciudadOrigen = new Ciudad("Bs As", "Bs As", "Argentina");
		Ciudad ciudadDestino = new Ciudad("Lima", "CHACLACAYO", "Peru");

		Aeropuerto airOrigen = new Aeropuerto("Aeropuerto Ezeiza", ciudadOrigen);
		Aeropuerto airDestino = new Aeropuerto("Aeropuerto Lima", ciudadDestino);
		
		LocalDateTime fechaInicio = LocalDateTime.of(2020, 2, 1, 0, 0, 0);
		LocalDateTime fechaFin = LocalDateTime.of(2020, 3, 1, 0, 0, 0);

		Vuelo vueloIda = new Vuelo(fechaInicio, fechaFin, 1, "Compania", "Apollo11", airOrigen, airDestino, 0,"");
		Vuelo vueloVuelta = new Vuelo(fechaFin, fechaInicio, 2, "Compania", "Apollo12", airDestino, airOrigen, 1,"");

		Viaje viajeUno = new Viaje("Peru", "", vueloIda, vueloVuelta);

		u.agregarViaje(viajeUno);

		LocalDateTime inicio = LocalDateTime.of(2020, 2, 1, 3, 0, 0);
		LocalDateTime fin = LocalDateTime.of(2020, 2, 1, 4, 0, 0);

		Actividad act = new Actividad(inicio,fin,"Pasear","Plaza","");
		viajeUno.agregarPlan(act);

		LocalDateTime inicioReserva = LocalDateTime.of(2020, 2, 2, 3, 0, 0);
		LocalDateTime finReserva = LocalDateTime.of(2020, 2, 2, 4, 0, 0);

		ReservaHotel reserva = new ReservaHotel(inicioReserva,finReserva,"hotel",348,1,"");
		viajeUno.agregarPlan(reserva);

		LocalDateTime inicioTraslado = LocalDateTime.of(2020, 2, 3, 3, 0, 0);
		LocalDateTime finTraslado = LocalDateTime.of(2020, 2, 3, 4, 0, 0);

		Traslado traslado = new Traslado(inicioTraslado,finTraslado,"","Hotel","Parque","");
		viajeUno.agregarPlan(traslado);

		LocalDateTime inicioHotel = LocalDateTime.of(2020, 2, 4, 3, 0, 0);
		LocalDateTime finHotel = LocalDateTime.of(2020, 2, 4, 4, 0, 0);

		ReservaHotel reservaHotel = new ReservaHotel(inicioHotel,finHotel,"h",543,76,"");
		LinkReservaHotel link = new LinkReservaHotel(u.getCorreo(),"www.ejemplo.com",2,reservaHotel);
		viajeUno.agregarPlan(link.getReserva());

		ArrayList<Viaje> misViajes = u.verViajes();
		System.out.println(misViajes);

	}
}
