package app;

import app.ubicacion.Mapa;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class Usuario {
	private String nombre;
	private String correo;
	private int dni;
	private ArrayList<Viaje> viajes;
	private LocalDateTime fechaNacimiento;
	
	public Usuario(String nombre, String correo, int dni, LocalDateTime fechaNacimiento) {
		this.nombre = nombre;
		this.correo = correo;
		this.dni = dni;
		this.viajes = new ArrayList<Viaje>();
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getNombre() {
		return nombre;
	}

	public String getCorreo() {
		return correo;
	}

	public int getDni() {
		return dni;
	}

	public LocalDateTime getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public void setDni(int dni) {
		this.dni = dni;
	}

	public void setFechaNacimiento(LocalDateTime fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	
	public void agregarViaje(Viaje viaje) {
		if (!viajes.contains(viaje))
			viajes.add(viaje);
	}

	public Mapa verMapa(Viaje viaje) {
		if (viajes.contains(viaje)) {
			return viaje.mostrarMapa();
		}else{
			return null;
		}
	}

	public ArrayList<Viaje> verViajes(){
		ArrayList<Viaje> salida = new ArrayList<>();
		for (int i = 0; i < viajes.size(); i++) {
			salida.add(viajes.get(i));
		}
		return salida;
	}
}
