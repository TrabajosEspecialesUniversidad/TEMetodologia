package app;

import app.plan.Plan;
import app.plan.Vuelo;
import app.ubicacion.Ciudad;
import app.ubicacion.Mapa;

import java.util.ArrayList;
import java.time.LocalDateTime;

public class Viaje {
	private String nombre;
	private Ciudad ciudadDestino;
	private LocalDateTime fechaInicio;
	private LocalDateTime fechaFin;
	private String descripcion;
	private ArrayList<Plan> planes;
	
	public Viaje(String nombre, String descripcion, Vuelo vueloIda, Vuelo vueloVuelta) {
		this.nombre = nombre;
		this.ciudadDestino = vueloIda.getDestino().getUbicacion();
		this.fechaInicio = vueloIda.getHoraInicio();
		this.fechaFin = vueloVuelta.getHoraFin();
		this.descripcion = descripcion;
		this.planes = new ArrayList<Plan>();
		planes.add(vueloIda);
		planes.add(vueloVuelta);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Ciudad getCiudadDestino() {
		return ciudadDestino;
	}

	public void setCiudadDestino(Ciudad ciudadDestino) {
		this.ciudadDestino = ciudadDestino;
	}

	public LocalDateTime getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(LocalDateTime fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public LocalDateTime getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(LocalDateTime fechaFin) {
		this.fechaFin = fechaFin;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public void agregarPlan(Plan plan) {
		if (planes.contains(plan))
			planes.add(plan);
	}

	public void eliminarPlan(Plan plan){
		planes.remove(plan);
	}

	public boolean estaRealizado(){
		int realizado = this.fechaFin.compareTo(LocalDateTime.now());
		return realizado <= 0;
	}

	public Mapa mostrarMapa(){
		Mapa m = new Mapa();
		for (int i = 0; i < planes.size(); i++) {
			m.agregarCoordenada(planes.get(i).getCoordenada());
		}
		return m;
	}

	@Override
	public String toString() {
		return "Viaje{" +
				"nombre='" + nombre + '\'' +
				", fecha_inicio=" + fechaInicio +
				", fecha_fin=" + fechaFin +
				", descripcion='" + descripcion + '\''
				+"\n"+"Planes="+ planes +
				'}';
	}
}
