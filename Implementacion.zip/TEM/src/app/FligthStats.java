package app;

import app.plan.Vuelo;

import java.time.LocalDateTime;

public interface FligthStats {
    //Esta clase solo modela la posibilidad de tener un sistema externo
    //Por esa razon lo dejamos como una interface y no implementamos sus metodos
    Vuelo getVuelo(String compania, int numeroVuelo, LocalDateTime fechaInicio);
}
