package app.plan;

import java.time.LocalDateTime;

public class Plan {
	private LocalDateTime horaInicio;
	private LocalDateTime horaFin;
	private String coordenada;

	public Plan(LocalDateTime horaInicio, LocalDateTime horaFin, String coordenada) {
		this.horaInicio = horaInicio;
		this.horaFin = horaFin;
		this.coordenada = coordenada;
	}

	public String getCoordenada() {
		return coordenada;
	}

	public void setCoordenada(String coordenada) {
		this.coordenada = coordenada;
	}

	public LocalDateTime getHoraInicio() {
		return horaInicio;
	}

	public LocalDateTime getHoraFin() {
		return horaFin;
	}

	public void setHoraInicio(LocalDateTime horaInicio) {
		this.horaInicio = horaInicio;
	}

	public void setHoraFin(LocalDateTime horaFin) {
		this.horaFin = horaFin;
	}

}
