package app.plan;

import java.time.LocalDateTime;

public class ReservaHotel extends Plan {
	private String nombre;
	private int codigoReserva;
	private int nroHabitacion;

	public ReservaHotel(LocalDateTime horaInicio, LocalDateTime horaFin, String nombre, int codigoReserva, int nroHabitacion, String coordenada) {
		super(horaInicio, horaFin,coordenada);
		this.nombre = nombre;
		this.codigoReserva = codigoReserva;
		this.nroHabitacion = nroHabitacion;
	}

	public String getNombre() {
		return nombre;
	}

	public int getCodigoReserva() {
		return codigoReserva;
	}

	public int getNroHabitacion() {
		return nroHabitacion;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setCodigoReserva(int codigoReserva) {
		this.codigoReserva = codigoReserva;
	}

	public void setNroHabitacion(int nroHabitacion) {
		this.nroHabitacion = nroHabitacion;
	}

	@Override
	public String toString() {
		return "ReservaHotel{" +
				"nombre='" + nombre + '\'' +
				", codigo_reserva=" + codigoReserva +
				", nro_habitacion=" + nroHabitacion +
				'}'+"\n";
	}
}
