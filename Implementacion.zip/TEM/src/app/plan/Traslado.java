package app.plan;

import java.time.LocalDateTime;

public class Traslado extends Plan{
      private String descricion;
      private String origen;
      private String destino;

    public Traslado(LocalDateTime horaInicio, LocalDateTime horaFin, String descricion, String origen, String destino,String coordenada) {
        super(horaInicio, horaFin, coordenada);
        this.descricion = descricion;
        this.origen = origen;
        this.destino = destino;
    }

    public String getDescricion() {
        return descricion;
    }

    public void setDescricion(String descricion) {
        this.descricion = descricion;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    @Override
    public String toString() {
        return "Traslado{" +
                "descricion='" + descricion + '\'' +
                ", origen='" + origen + '\'' +
                ", destino='" + destino + '\'' +
                '}'+"\n";
    }
}
