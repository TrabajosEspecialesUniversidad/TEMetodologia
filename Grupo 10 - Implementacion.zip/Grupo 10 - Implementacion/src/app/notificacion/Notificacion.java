package app.notificacion;

import app.usuario.Usuario;

public abstract class Notificacion {
	private String texto;
	
	public Notificacion(String texto) {
		this.texto = texto;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public abstract boolean notificar(Usuario usuario);
}
