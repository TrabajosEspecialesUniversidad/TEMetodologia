package app.notificacion;

import app.usuario.Usuario;

public class NotificacionCinta extends Notificacion {

	public NotificacionCinta(String texto) {
		super(texto);
	}

	@Override
	public boolean notificar(Usuario usuario) {
		if (usuario.esPremium())
			return true;
		return false;
	}

}
