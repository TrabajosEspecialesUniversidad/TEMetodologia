package app.notificacion;

import app.usuario.Usuario;

public class NotificacionCambioPlan extends Notificacion {

	public NotificacionCambioPlan(String texto) {
		super(texto);
	}

	@Override
	public boolean notificar(Usuario usuario) {
		if (usuario.esPremium())
			return true;
		return false;
	}

}
