package app.notificacion;

import app.usuario.Usuario;

public class NotificacionMostrador extends Notificacion {

	public NotificacionMostrador(String texto) {
		super(texto);
	}
	
	@Override
	public boolean notificar(Usuario usuario) {
		if (usuario.esPremium())
			return true;
		return false;
	}
}
