package app.notificacion;

import app.usuario.Usuario;

public class NotificacionVuelo extends Notificacion {

	public NotificacionVuelo(String texto) {
		super(texto);
	}
	
	@Override
	public boolean notificar(Usuario usuario) {
		return true;
	}
}
