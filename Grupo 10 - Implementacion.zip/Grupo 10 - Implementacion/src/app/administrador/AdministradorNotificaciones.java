package app.administrador;

import java.util.ArrayList;
import app.usuario.Usuario;
import app.notificacion.Notificacion;

public class AdministradorNotificaciones {
	private ArrayList<Usuario> usuarios;
	
	public AdministradorNotificaciones() {
		this.usuarios = new ArrayList<>();
	}

	public void agregarUsuario(Usuario usuario) {
		if (!usuarios.contains(usuario))
			this.usuarios.add(usuario);
	}
	
	public void ejecutarNotificacion(Notificacion notificacion) {
		for (Usuario usuarioActual: usuarios)
			notificacion.notificar(usuarioActual);
	}
}
