package app.administrador;

import app.viaje.Viaje;
import app.link.LinkVuelo;
import app.plan.Vuelo;

public class AdministradorViaje {

	public LinkVuelo generarLink(String enlace, String mail, int codigoReserva, Vuelo vueloIda, Vuelo vueloVuelta) {
		return new LinkVuelo(enlace, mail, codigoReserva, vueloIda, vueloVuelta);
	}
	
	public Viaje generarViaje(String nombre, String descripcion, LinkVuelo linkVuelo) {
		Vuelo vueloIda = linkVuelo.getVueloIda();
		Vuelo vueloVuelta = linkVuelo.getVueloVuelta();
		return new Viaje(nombre, descripcion, vueloIda, vueloVuelta);
	}

	public  Vuelo crearVueloAerolinea(){
		Vuelo vuelo = new Vuelo(AdministradorAerolinea.getFechaInicio(), AdministradorAerolinea.getFechaFin(), AdministradorAerolinea.getNumVuelo(), AdministradorAerolinea.getCompania(), AdministradorAerolinea.getAeronave(),
				AdministradorAerolinea.getOrigen(), AdministradorAerolinea.getDestino(), AdministradorAerolinea.getCodReserva(), AdministradorAerolinea.getCoordenada());
		return vuelo;
	}

}
