package app.administrador;

import app.aeropuerto.Aeropuerto;
import app.ubicacion.Ciudad;
import java.time.LocalDateTime;
import java.util.Random;

public class AdministradorAerolinea {

    public static String getCoordenada() {
        return "coordenada";
    }

    public static int getCodReserva() {

        return new Random().nextInt(200000);
    }

    public static int getNumVuelo() {
        return new Random().nextInt(200000);
    }

    public static Aeropuerto getOrigen() {
        return new Aeropuerto("ciudad",new Ciudad("ciudad","ejemplo","pais"));
    }

    public static Aeropuerto getDestino() {
        return new Aeropuerto("ciudadDestino",new Ciudad("ciudadDestino","ejemplo","pais"));
    }

    public static String getCompania() {
        return "compania";
    }

    public static String getAeronave() {
        return new Random().nextInt(200000)+" aeronave";
    }

    public static LocalDateTime getFechaFin() {
        return LocalDateTime.of(new Random().nextInt(2020),new Random().nextInt(10)+1,
                new Random().nextInt(25)+1,new Random().nextInt(10),new Random().nextInt(50));
    }

    public static LocalDateTime getFechaInicio() {
        return LocalDateTime.of(new Random().nextInt(2020),new Random().nextInt(10)+1,
                new Random().nextInt(25)+1,new Random().nextInt(10),new Random().nextInt(50));
    }

}
