package app;

import app.usuario.Usuario;

public interface Grafico {
	public void frecuenciaViajes(Usuario usuario);
	public void kilometrosRecorridos(Usuario usuario);
	public void paisesVisitados(Usuario usuario);
	
	// Asumimos que cada metodo genera y muestra el grafico correspondiente a cada estadistica solicitada
}
