package app.aeropuerto;

import java.time.LocalDateTime;

public class Mostrador {
      private String compania;
      private LocalDateTime horarioApertura;
      private LocalDateTime horarioCierre;

    public Mostrador(String compania, LocalDateTime horarioApertura, LocalDateTime horarioCierre) {
        this.compania = compania;
        this.horarioApertura = horarioApertura;
        this.horarioCierre = horarioCierre;
    }

    public String getCompania() {
        return compania;
    }

    public void setCompania(String compania) {
        this.compania = compania;
    }

    public LocalDateTime getHorarioApertura() {
        return horarioApertura;
    }

    public void setHorarioApertura(LocalDateTime horarioApertura) {
        this.horarioApertura = horarioApertura;
    }

    public LocalDateTime getHorarioCierre() {
        return horarioCierre;
    }

    public void setHorarioCierre(LocalDateTime horarioCierre) {
        this.horarioCierre = horarioCierre;
    }
}
