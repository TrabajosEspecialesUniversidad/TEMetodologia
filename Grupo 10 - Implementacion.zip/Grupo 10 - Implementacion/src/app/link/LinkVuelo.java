package app.link;

import app.plan.Vuelo;

public class LinkVuelo extends Link {
	private Vuelo vueloIda;
	private Vuelo vueloVuelta;
	
	public LinkVuelo(String email, String enlace, int codigoReserva, Vuelo vueloIda, Vuelo vueloVuelta) {
		super(email, enlace, codigoReserva);
		this.vueloIda = vueloIda;
		this.vueloVuelta = vueloVuelta;
	}

	public Vuelo getVueloIda() {
		return vueloIda;
	}
	
	public Vuelo getVueloVuelta() {
		return vueloVuelta;
	}
}
