package app.link;

public class Link {
	private String email;
	private String enlace;
	private int codigoReserva;
	
	public Link(String email, String enlace, int codigoReserva) {
		this.email = email;
		this.enlace = enlace;
		this.codigoReserva = codigoReserva;
	}

	public String getEmail() {
		return email;
	}

	public String getEnlace() {
		return enlace;
	}

	public int getCodigoReserva() {
		return codigoReserva;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setEnlace(String enlace) {
		this.enlace = enlace;
	}

	public void setCodigoReserva(int codigoReserva) {
		this.codigoReserva = codigoReserva;
	}
}
