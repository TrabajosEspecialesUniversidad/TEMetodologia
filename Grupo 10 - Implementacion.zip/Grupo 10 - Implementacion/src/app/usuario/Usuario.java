package app.usuario;

import app.viaje.Viaje;
import app.ubicacion.Mapa;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.ArrayList;

public class Usuario {
	private String nombre;
	private String correo;
	private int dni;
	private ArrayList<Viaje> viajes;
	private LocalDateTime fechaNacimiento;
	private boolean esAdministrador;
	private LocalDate inicioPremium;

	public Usuario(String nombre, String correo, int dni, LocalDateTime fechaNacimiento) {
		this.nombre = nombre;
		this.correo = correo;
		this.dni = dni;
		this.viajes = new ArrayList<Viaje>();
		this.fechaNacimiento = fechaNacimiento;
		this.inicioPremium = LocalDate.of(1,1,1);
		this.esAdministrador = false;
	}

	public String getNombre() {
		return nombre;
	}

	public String getCorreo() {
		return correo;
	}

	public int getDni() {
		return dni;
	}

	public LocalDateTime getFechaNacimiento() {
		return fechaNacimiento;
	}
	
	public boolean esAdmnistrador() {
		return esAdministrador;
	}
	
	public Viaje getViajeProximo() {
		for (Viaje viaje_actual: viajes)
			if (!viaje_actual.estaRealizado())
				return viaje_actual;
		return null;
	}
	
	public boolean esPremium() {
		Period periodo = Period.between(inicioPremium, LocalDate.now());
		return periodo.getYears() < 1;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public void setDni(int dni) {
		this.dni = dni;
	}

	protected void setEsAdministrador(boolean esAdministrador) {
		this.esAdministrador = esAdministrador;
	}

	public void setFechaNacimiento(LocalDateTime fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	
	public void agregarViaje(Viaje viaje){
			int i = 0;
			boolean solapado = false;
			while (i < viajes.size() && !solapado) {
				if (this.seSolapan(viaje, viajes.get(i)))
					solapado = true;
				i++;
			}
			if (!solapado)
				this.insertarOrdenado(viaje);
	}

	public Mapa verMapa(Viaje viaje) {
		if (viajes.contains(viaje)) {
			return viaje.mostrarMapa();
		}else{
			return null;
		}
	}

	public ArrayList<Viaje> verViajes(){
		ArrayList<Viaje> salida = new ArrayList<>();
		for (int i = 0; i < viajes.size(); i++) {
			salida.add(viajes.get(i));
		}
		return salida;
	}
	
	private boolean seSolapan(Viaje viaje1, Viaje viaje2) {
		LocalDateTime fechaInicio1 = viaje1.getFechaInicio();
		LocalDateTime fechaInicio2 = viaje2.getFechaInicio();
		LocalDateTime fechaFin1 = viaje1.getFechaFin();
		LocalDateTime fechaFin2 = viaje2.getFechaFin();
		return ((fechaInicio1.compareTo(fechaFin2) < 0) && (fechaInicio1.compareTo(fechaInicio2) > 0)) ||
		 		((fechaFin1.compareTo(fechaFin2) < 0) && (fechaFin1.compareTo(fechaInicio2) > 0));
	}
	
	private void insertarOrdenado(Viaje viaje) {
			int i = 0;
			boolean insertado = false;
			while (i < viajes.size() && !insertado) {
				if (viajes.get(i).getFechaInicio().compareTo(viaje.getFechaInicio()) > 0) {
					viajes.add(i, viaje);
					insertado = true;
				}
				i++;
			}
			if (!insertado){
				viajes.add(viaje);
			}
	}

	public void suscribir(Tarjeta tarjeta){
		if (tarjeta.pagar()){
			inicioPremium = LocalDate.now();
		}
	}
}

