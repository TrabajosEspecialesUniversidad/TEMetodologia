package app.usuario;

import java.time.LocalDateTime;

public class Tarjeta {
    String banco;
    int nroTarjeta;
    LocalDateTime fechaVencimiento;

    public Tarjeta(String banco, int nroTarjeta, LocalDateTime fechaVencimiento) {
        this.banco = banco;
        this.nroTarjeta = nroTarjeta;
        this.fechaVencimiento = fechaVencimiento;
    }

    public String getBanco() {
        return banco;
    }

    public int getNroTarjeta() {
        return nroTarjeta;
    }

    public LocalDateTime getFechaVencimiento() {
        return fechaVencimiento;
    }

    public boolean pagar(){
        return true;
    }
}
