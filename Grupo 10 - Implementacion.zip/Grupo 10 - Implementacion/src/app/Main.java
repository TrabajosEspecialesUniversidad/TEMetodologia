package app;

import app.administrador.AdministradorViaje;
import app.usuario.Usuario;
import app.viaje.Viaje;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		//Ejemplo para probar el funcionamiento
		LocalDateTime fechaNacimiento = LocalDateTime.of(1997, 2, 1, 0, 0, 0);
		Usuario primerUsuario = new Usuario("ejemplo", "ejemplo@gmail.com", 1, fechaNacimiento);

		AdministradorViaje administrador = new AdministradorViaje();
		Viaje primerViaje = administrador.generarViaje("","",administrador.generarLink("www..",primerUsuario.getCorreo(),1,administrador.crearVueloAerolinea(),administrador.crearVueloAerolinea()));

		primerUsuario.agregarViaje(primerViaje);

		ArrayList<Viaje> misViajes = primerUsuario.verViajes();
		System.out.println(misViajes);

	}
}
