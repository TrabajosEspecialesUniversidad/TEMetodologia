package app.ubicacion;

import java.util.ArrayList;

public class Mapa {
    private ArrayList<String> coordenadas;

    public Mapa() {
        this.coordenadas = new ArrayList<>();
    }

    public ArrayList<String> getCoordenadas() {
        ArrayList<String> aux = new ArrayList<>();
        for (int i = 0; i < coordenadas.size(); i++) {
            aux.add(coordenadas.get(i));
        }
        return aux;
    }

    public void agregarCoordenada(String coordenada){
        if (!coordenadas.contains(coordenada)){
            coordenadas.add(coordenada);
        }
    }
}
