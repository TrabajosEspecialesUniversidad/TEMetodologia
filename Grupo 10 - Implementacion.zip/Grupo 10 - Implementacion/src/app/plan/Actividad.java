package app.plan;

import java.time.LocalDateTime;

public class Actividad extends Plan {
	private String descipcion;
	private String lugar;
	
	public Actividad(LocalDateTime horaInicio, LocalDateTime horaFin, String descipcion, String lugar,String coordenada) {
		super(horaInicio, horaFin,coordenada);
		this.descipcion = descipcion;
		this.lugar = lugar;
	}

	public String getDescipcion() {
		return descipcion;
	}

	public String getLugar() {
		return lugar;
	}

	public void setDescipcion(String descipcion) {
		this.descipcion = descipcion;
	}

	public void setLugar(String lugar) {
		this.lugar = lugar;
	}

	@Override
	public String toString() {
		return "Actividad{" +
				"descipcion'" + descipcion + '\'' +
				", lugar'" + lugar + '\'' +
				'}';
	}
}
