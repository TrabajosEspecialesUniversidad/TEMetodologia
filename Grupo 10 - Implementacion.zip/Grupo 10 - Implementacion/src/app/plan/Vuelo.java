package app.plan;

import app.aeropuerto.Aeropuerto;
import app.aeropuerto.Escala;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Vuelo extends Plan {
	private int nroVuelo;
	private String compania;
	private String aeronave;
	private Aeropuerto origen;
	private Aeropuerto destino;
	private int codigoReserva;
	ArrayList<Escala> escalas;
	//todo String para ver donde se deposita el equipaje

	public Vuelo(LocalDateTime horaInicio, LocalDateTime horaFin, int nroVuelo, String compania, String aeronave, Aeropuerto origen,
			Aeropuerto destino, int codigoReserva, String coordenada) {
		super(horaInicio, horaFin, coordenada);
		this.nroVuelo = nroVuelo;
		this.compania = compania;
		this.aeronave = aeronave;
		this.origen = origen;
		this.destino = destino;
		this.codigoReserva = codigoReserva;
		this.escalas = new ArrayList<Escala>();
	}

	public int getNroVuelo() {
		return nroVuelo;
	}

	public String getCompania() {
		return compania;
	}

	public String getAeronave() {
		return aeronave;
	}

	public Aeropuerto getOrigen() {
		return origen;
	}

	public Aeropuerto getDestino() {
		return destino;
	}

	public int getCodigoReserva() {
		return codigoReserva;
	}

	public void setNroVuelo(int nroVuelo) {
		this.nroVuelo = nroVuelo;
	}

	public void setCompania(String compania) {
		this.compania = compania;
	}

	public void setAeronave(String aeronave) {
		this.aeronave = aeronave;
	}

	public void setOrigen(Aeropuerto origen) {
		this.origen = origen;
	}

	public void setDestino(Aeropuerto destino) {
		this.destino = destino;
	}

	public void setCodigoReserva(int codigoReserva) {
		this.codigoReserva = codigoReserva;
	}

	public void addEscala(Escala escala) {
		if (!escalas.contains(escala))
			escalas.add(escala);
	}

	@Override
	public String toString() {
		return "Vuelo{" +
				"nroVuelo=" + nroVuelo +
				", compania='" + compania + '\'' +
				", aeronave='" + aeronave + '\'' +
				", origen=" + origen.getNombre() +
				", destino=" + destino.getNombre() +
				", codigoReserva=" + codigoReserva +
				'}';
	}
}
